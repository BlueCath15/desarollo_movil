package com.fisiocare.miau.ui.theme
/*
class persona(val nombre:String,  var edad:Int) {
    fun saludar(){
        println("hello, $nombre" +
                "y $edad años")
    }

    //declaracion de atributos
    var idpersona: String =  ""
    var nombrepersona: String = ""
    //var edad:Int = 0

//
    fun presentarpersona() {
        println("buen dia mi nombre es $nombrepersona y tengo $edad anos")
    }
}

class estudiante (val idestudiante: String, var nombreestudiante:  String, var edadestudiante:Int){
    var cursoestudiante: String = ""

    constructor(idestudiante: String)
}
*/