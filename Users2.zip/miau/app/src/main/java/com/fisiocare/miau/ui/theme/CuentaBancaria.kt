package com.fisiocare.miau.ui.theme

import java.util.function.DoubleConsumer

class CuentaBancaria (private var saldo :Double){
    fun depositarDinero (monto:Double){
        saldo += monto
        println("su saldo es $saldo")
    }
    fun obtenerSaldo(): Double{
        return saldo
    }
}

fun main (){
    val cuenta =CuentaBancaria(1000.0)
    cuenta.depositarDinero(500.0)
    val saldo1 = cuenta.obtenerSaldo()
    println("$saldo1")
}