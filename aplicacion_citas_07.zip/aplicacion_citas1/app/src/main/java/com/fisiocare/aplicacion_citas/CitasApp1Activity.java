package com.fisiocare.aplicacion_citas;

import android.app.Activity;

public class CitasApp1Activity extends Activity {

    val spinner: Spinner = findViewById(R.id.spinnerCitas)
    val opciones = listOf("Médico general", "Odontología", "Fisioterapia", "Psicología")

    val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, opciones)
adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

    spinner.adapter = adapter
}
