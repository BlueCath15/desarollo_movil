package com.example.users1.database
import androidx.lifecycle.LiveData
import androidx.room.*

@Entity(tableName="users")
data class User(
    @PrimaryKey(autoGenerate =true)val id:Int=0,
    val name:String,

)
