package com.example.users.models

data class Usuario()
