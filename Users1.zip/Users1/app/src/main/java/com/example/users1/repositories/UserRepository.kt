package com.example.users1.repositories

class UserRepository {
}