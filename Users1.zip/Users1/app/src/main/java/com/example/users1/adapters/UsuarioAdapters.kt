package com.example.users.adapters

data class UsuarioAdapters()
