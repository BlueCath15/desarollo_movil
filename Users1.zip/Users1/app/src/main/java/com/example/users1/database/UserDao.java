package com.example.users1.database;
import androidx.lifecycle.LiveData;
import androidx.room.*;

import java.util.List;

@Dao

public interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    @Delete suspend fun delete(user: User)
    @Query("select * from users order by name asc" )
    fun getAllUsers():LiveData<List<User>>
}
