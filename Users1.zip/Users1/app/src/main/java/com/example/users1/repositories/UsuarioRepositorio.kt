package com.example.users.repositories

data class UsuarioRepositorio()
