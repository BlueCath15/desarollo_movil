package com.example.users1.adapters

class UserAdapter {
}