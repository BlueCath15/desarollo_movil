package com.example.users.viewModels
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.users.database.UserDatabase
import com.example.users.repositories.UsuarioRepositorio
import com.example.users1.repositories.UserRepository
import hotlinx.coroutines.launch

class UsuarioViewModel (application: Application):AndroidViewModel(application) {
    private val repository:UserRepository
    val allUsers:LiveData<List<User>>

    init {
        val userDao = UserDatabase.getDatabase(application).userDao()
        repository = UserRepository(userDao)
        allUsers = repository.allUser

    }

    fun insert (user:User) = vie
}

